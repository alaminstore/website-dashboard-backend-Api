@extends('backend.home')
@section('title','Dashboard')
@section('content')
        <br>
        <br>
        <br>
        <br>
<div class="container">
    <div class="row text-center">
        <h6 class="display-4">Dashboard Area...</h6>
    </div>
</div>
@endsection
